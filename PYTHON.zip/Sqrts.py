def mysqrt(n):
    """Find's the Square of a number using Newton's algorithm"""
    oldguess = n/2
    for i in range(1000):
        newguess = (1 / 2) * (oldguess + (n / oldguess))
        oldguess = newguess
    return newguess


counter = 1

num = int(input("Enter a number for it to be square rooted: "))
while counter > 0:
    if num > 0:
        print(mysqrt(num))
        break
    else:
        print("Cannot square root a negative number. Please Re-Enter")
        num = int(input("Enter a number for it to be square rooted: "))


