import math


def myPi(k):
    while k < 100:
        k = k + 1
        aPi = aPi + (((-3) ** -k) / ((2 * k) + 1))

    math.sqrt(12) * aPi
    print(aPi)
