import turtle
import time
wn = turtle.Screen()
wn.bgcolor('Black')
t = turtle.Turtle()
time.sleep(1)
t.speed(20)

loops = 0

while loops < 100:
    loops = loops + 1


t.speed(0)

# w determines each side width
w = 20
# l determines each side length
l = 200

# c1 c2 and c3 are the 3 fill colours, you can use hex values or some words like "red"
c1 = "#EECCFF"
c2 = "#880044"
c3 = "#D0FF00"

# linec is the line colour and linew is the line thiccness
linec = "black"
linew = 1

# linevisible to true if you want a line, false if you don't want a line
linevisible = True

if linevisible:
  t.pd()
else:
  t.pu()  
t.pencolor(linec)
t.width(linew)
for c in [c1, c2, c3]:
  t.fillcolor(c)
  t.begin_fill()
  t.forward(w)
  t.right(60)
  t.forward(l)
  t.right(120)
  t.forward(l-w)
  t.right(120)
  t.forward(w)
  t.right(60)
  t.forward(l-3*w)
  t.left(120)
  t.forward(l-w)
  t.right(120)
  t.end_fill()

  t.forward(w)
  t.right(60)
  t.forward(l)
  t.right(60)

t.hideturtle()
wn.exitonclick()