#task 3

import random
x = 0
y = 0

x, y = int(input("enter a number for X: ")), int(input("enter a number for Y: "))
RandomNumbers = []


isTrue = False

for i in range (20):
   if x < y and y - x  >= 20:
       isTrue = True
   else:
       print("X is not greater than Y or the sum of X and Y does not equal 20")
       x, y = int(input("re-enter a number for X: ")), int(input("re-enter a number for y: "))

   if isTrue == True:
       randomvalues = random.randrange(x,y)
       RandomNumbers.append(randomvalues)
print(RandomNumbers)

#Extension

RandomNumbers = list(dict.fromkeys(RandomNumbers))
print (RandomNumbers)