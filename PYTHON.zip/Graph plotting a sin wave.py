import math
import turtle

wn = turtle.Screen()
wn.bgcolor('black')
fred = turtle.Turtle()
wn.setworldcoordinates(0,-1.5,15,1.5)
fred.pencolor('hotpink')
fred.write("0", align="left", font=("Times New Roman", 30, "normal"))
fred.speed(0)
fred.pensize(3)

fred.forward(360)
fred.penup()
fred.goto(0,0)
fred.pendown()
fred.left(90)
fred.forward(360)
fred.penup()
fred.goto(0,0)
fred.pendown()
fred.right(180)
fred.forward(360)
fred.penup()
fred.goto(0,0)
fred.pendown()
angle= 0

while angle < (6 * math.pi):
    y = math.sin(angle)
    fred.goto(angle, y)
    angle += 0.1

wn.exitonclick()
