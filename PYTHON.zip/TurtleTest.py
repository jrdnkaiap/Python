import turtle
import colorsys


def drawSpiral(t, angle):
    length = 25
    for i in range(500):
        for x in reversed(range(0, num)):
            t.color(colorsys.hsv_to_rgb(x / num, 1.0, 1.0))
            # t.hideturtle()
            t.forward(length)
            t.right(angle)
            length = length + 0.5


wn = turtle.Screen()
wn.bgcolor("black")

jordan = turtle.Turtle()
num = 200

jordan.speed(0)


jordan.penup()
jordan.backward(100)
jordan.pendown()


drawSpiral(jordan, float(input("Enter angle: ")))

wn.exitonclick()

