from image import ImageWin, FileImage, EmptyImage
from cimage import *
myimagewindow = ImageWin("Image Processing",900,300)
oldimage = FileImage("LutherBellPic.gif")
oldimage.setPosition(0,0)
oldimage.draw(myimagewindow)

print("old printed")
input("hit a key ...")

width = oldimage.getWidth()
height = oldimage.getHeight()
newim = EmptyImage(width,height)
print(width,height, width*height)

for row in range(height):
    for col in range(width):
            oldpixel = oldimage.getPixel(col,row)
            ave=int((oldpixel.getRed()+oldpixel.getGreen()+oldpixel.getBlue())/3)
            newim.setPixel(col,row,Pixel(ave,ave,ave))

newim.setPosition(width+1,0)
newim.draw(myimagewindow)

myimagewindow.exitOnClick()


class Pixel(object):
    pass