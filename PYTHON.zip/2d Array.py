data = "AAAAAAAAAAAAAAAABBBBBBBBBBBBBSSSSSSSSSFFFFFFFF"

val = 0

# for i in range(20):
#     for j in range(20):
#         data.append(val)
#     if val == 0:
#         val = 10
#     else:
#         val = 0
# print(data)


"""RLE Encode"""
encoding = ''
prev_char = ''
count = 1

for char in data:
    if char != prev_char:
        if prev_char:
            encoding += prev_char + str(count)
            count = 1
            prev_char = char
        else:
            count += 1
else:
    encoding += prev_char + str(count)
    print(encoding)

# RLE = []
# prev = ''
# for v in data:
#     if str(v) in prev:
#         newV = [v, 1]
#         RLE.append(newV)

