def sumTo(n):
    result = (n * (n + 1)) / 2
    return result


# Using the function
t = sumTo(0)
print("The sum from 1 to 0 is", t)
t = sumTo(1000)
print("The sum from 1 to 10 is", t)
t = sumTo(5)
print("The sum from 1 to 5 is", t)
