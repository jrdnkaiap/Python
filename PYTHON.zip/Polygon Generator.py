import turtle
wn = turtle.Screen()
jordan = turtle.Turtle()


wn.bgcolor("black")


def DrawPoly(n):
    for i in range(n):
        jordan.forward(100)
        jordan.left(360 / n)


jordan.color("hotpink")

for i in range(3, 10):
    DrawPoly(i)
a = '5'
b = 3
print(a + b)



wn.exitonclick()
