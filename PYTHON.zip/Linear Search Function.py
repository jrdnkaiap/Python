# Searching an element in a list/array in python
# can be simply done using \'in\' operator
# Example:
# if x in arr:
#   print arr.index(x)

# If you want to implement Linear Search in python

# Linearly search x in arr[]
# If x is present then return its location
# else return -1

#style 1
def search(arr, x):
    for i in range(len(arr)):

        if arr[i] == x:
            return i

    return -1

#style 2

def linearSearch(intList,target):
    found = False
    position = 0
    while position < len(intList) and not found:
        if intList[position] == target:
            found = True
        position = position + 1

    return found

linearList = [3,5,9,7,6,12,15,9,1]
numInput = input("What number are you looking for? ")
numFound = linearSearch(linearList, numInput)
if numFound:
    print("The number is in index: ")
else:
    print("The number is not in the list")