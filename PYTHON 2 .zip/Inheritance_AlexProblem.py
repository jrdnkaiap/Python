class Performer():
    def __init__(self, firstName, lastName, secondaryRole, stageName, perfType):

        self.__firstName = firstName
        self.__lastName = lastName
        self.__secondaryRole = secondaryRole
        self.__stageName = stageName
        self.__perfType = perfType
      
    def getFirstName(self):
        return self.__firstName

    def getLastName(self):
        return self.__lastName

    def getSecondaryRole(self):
        return self.__secondaryRole

    def getStageName(self):
        return self.__stageName

    def getPerfType(self):
        return self.__perfType
    
    def __str__(self):
        return ("First Name: %s \nLast Name %s \nSecondary Role: %s \nStage Name: %s \nPerf Type: %s \n" % (self.__firstName,self.__lastName,self.__secondaryRole,self.__stageName,self.__perfType))


class acrobat(Performer):
    def __init__(self, firstName, lastName, secondaryRole, stageName, perfType, useFire):
        super().__init__(firstName, lastName, secondaryRole, stageName, perfType)
        self.__useFire = useFire          
    
    def getUseFire(self):
        return self.__useFire

    def __str__(self):
        return super().__str__() + "UsesFire: %s" %(self.__useFire)


class clown(Performer):
    def __init__(self, firstName, lastName, secondaryRole, stageName, perfType="Clown", clownInstrument, clownItem):
        super().__init__(firstName, lastName, secondaryRole, stageName, perfType)
        self.__clownInstrument = clownInstrument
        self.__clownItem = clownItem
 
    def getClownInstrument(self):
        return self.__clownInstrument
    
    def getClownItem(self):
        return self.__clownItem


    def __str__(self):
        return super().__str__() + "Item: %s \nInstrument: %s" %(self.__clownItem,self.__clownInstrument)


class aerial(Performer):
    def __init__(self, firstName, lastName, secondaryRole, stageName, perfType="aerial",aerialType):
        super().__init__(firstName, lastName, secondaryRole, stageName, perfType)
        self.__aerialType = aerialType

    def getAerialType(self):
        return self.__aerialType

    def __str__(self):
        return super().__str__() + "\nAerialType: %s" %(self.__aerialType)