class point():

    def __init__(self):
        """ initialises varaibles for a user defined class """
        self.__x = 0
        self.__y = 0 

    def __str__(self):
        """ return's point data as a string """
        return ("x= " + str(self.__x) + " y= " + str(self.__y))
    
    def SetX(self,x):
        self.__x = x 

p = point()
p.SetX(33)
print(p)
