emptyDict = {}

thisdict = {
    'aName':Jordan,
    'Class':Idiot,
    'Age':"17"
}

hash("abc")
