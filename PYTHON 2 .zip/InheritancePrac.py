class Vehicle():
    def __init__(self, Type ="general", passengers=1, mass=0, dateOfReg=0):
        self.__vehicleType = Type
        self.__passengers = passengers       
        self.__mass = mass
        self.__dateOfReg = dateOfReg

class car(vehicle):
    def __init__(self, Type ="general", passengers=1, mass=0, dateOfReg=0, NoOfDoors):
        super.__init__(...)