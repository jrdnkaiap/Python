#Factorial Recursion Python 
def factorial(n):

    if n == 0:      #Base Case (Always stepping back to THIS)
        result = 1 
    else:
        result = n * factorial(n-1)     #General Case & Recursive Call 

    print("Value of n at" , n+1 ,"(in 'RAM')" , "is: " , n , "\n" "The result at" , n+1 ,"(in 'RAM')"  " is: " , result , "\n" )
    
    return result

print(factorial(int(input("Enter Value: "))))