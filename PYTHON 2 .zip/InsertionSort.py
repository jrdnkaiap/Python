import random 
def insertionSort(A):
   for i in range(1, len(A)):
      item = A[i]
      # Move elements of A[0 -> i-1], that are greater than item, to one position ahead of their current position
      iHole = i-1
      while iHole >=0 and item < A[iHole] :
         A[iHole+1] = A[iHole]
         iHole -= 1
      A[iHole+1] = item


# main
A = [random.randrange(1,100) for i in range (100)]
print("The unsorted arry is: ")
for i in range(len(A)):
    print (A[i])

insertionSort(A)
print ("\nThe sorted array is:")

for i in range(len(A)):
   print (A[i])