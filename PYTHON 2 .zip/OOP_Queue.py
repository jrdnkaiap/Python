class queue():
    # constructor 
    def __init__(self, size=10): # initializing the class 
        self.size = size 
          
        #init
        self.queue = [None for i in range(size)]  
        self.front = self.back = -1

    def add(self, data):    
        # if full 
        if ((self.back + 1) % self.size == self.front):  
            print(" Queue is Full") 
              80
        # if empty  
        elif (self.front == -1):  
            self.front = 0
            self.back = 0
            self.queue[self.back] = data 
        else:  
            self.back = (self.back + 1) % self.size  
            self.queue[self.back] = data 


    def get()
        if (self.front == -1): 
            print ("Queue is Empty") 
              
        elif (self.front == self.back):  
            temp=self.queue[self.front] 
            self.front = -1
            self.back = -1
            return temp 
        else: 
            temp = self.queue[self.front] 
            self.front = (self.front + 1) % self.size 
            return temp 


    def display(self): 
        
            # if empty
            if(self.front == -1):  
                print ("Queue is Empty") 
    
            elif (self.back >= self.front): 
                print("Elements in the circular queue are:", end = " ") 
                for i in range(self.front, self.back + 1): 
                    print(self.queue[i], end = " ") 
                print () 
    
            else: 
                print ("Elements in Circular Queue are:",  end = " ") 
                for i in range(self.front, self.size): 
                    print(self.queue[i], end = " ") 
                for i in range(0, self.back + 1): 
                    print(self.queue[i], end = " ") 
                print () 
    
            if ((self.back + 1) % self.size == self.front): 
                print("Queue is Full")